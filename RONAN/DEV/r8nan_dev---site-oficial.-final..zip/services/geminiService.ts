import { GoogleGenAI } from "@google/genai";

// Initialize the client
// The API key is injected automatically into process.env.API_KEY
// Note: For Veo, we re-instantiate inside the function to ensure we get the user-selected key if updated.
const MODEL_NAME_IMAGE = 'gemini-2.5-flash-image';
const MODEL_NAME_VIDEO = 'veo-3.1-fast-generate-preview';

export const editImageWithGemini = async (
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: MODEL_NAME_IMAGE,
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    // Iterate through parts to find the image
    const parts = response.candidates?.[0]?.content?.parts;
    
    if (!parts) {
      throw new Error("No content generated");
    }

    for (const part of parts) {
      if (part.inlineData && part.inlineData.data) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    // Fallback if only text is returned (e.g., refusal or error explanation)
    const textPart = parts.find(p => p.text);
    if (textPart?.text) {
      throw new Error(`Model returned text instead of image: ${textPart.text}`);
    }

    throw new Error("No image data found in response");

  } catch (error: any) {
    console.error("Gemini Image Edit Error:", error);
    throw new Error(error.message || "Failed to edit image");
  }
};

export const generatePromoVideo = async (prompt: string): Promise<string> => {
  try {
    // Create a new instance to ensure we use the latest API key selected by the user
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    let operation = await ai.models.generateVideos({
      model: MODEL_NAME_VIDEO,
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '16:9'
      }
    });

    // Poll for completion
    while (!operation.done) {
      // Wait 5 seconds before checking again
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({operation: operation});
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    
    if (!videoUri) {
      throw new Error("Video generation completed but no URI was returned.");
    }

    // The response.body contains the MP4 bytes. You must append an API key when fetching from the download link.
    // However, for the frontend to play it, we need to fetch it and convert to a blob URL 
    // because the direct link requires auth headers/params that the <video> tag doesn't handle easily 
    // without exposing the key in the src attribute directly.
    
    const downloadUrl = `${videoUri}&key=${process.env.API_KEY}`;
    const videoResponse = await fetch(downloadUrl);
    
    if (!videoResponse.ok) {
       throw new Error(`Failed to download video: ${videoResponse.statusText}`);
    }
    
    const blob = await videoResponse.blob();
    return URL.createObjectURL(blob);

  } catch (error: any) {
    console.error("Veo Video Gen Error:", error);
    // Handle specific API errors
    if (error.message?.includes("Requested entity was not found")) {
      throw new Error("API Key Error: Please re-select your API key.");
    }
    throw new Error(error.message || "Failed to generate video");
  }
};
