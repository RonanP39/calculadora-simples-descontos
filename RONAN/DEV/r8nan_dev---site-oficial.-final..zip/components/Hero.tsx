
import React from 'react';
import { ArrowRight, Github, Linkedin, MessageCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface HeroProps {
  onProjectsClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onProjectsClick }) => {
  const { t } = useLanguage();

  return (
    <section className="relative min-h-screen pt-20 px-6 flex items-center overflow-hidden">
      {/* Dynamic Background Blurs */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-[120px] animate-pulse-glow"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-secondary/10 rounded-full blur-[120px] animate-pulse-glow" style={{ animationDelay: '2s' }}></div>

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        
        <div className="lg:col-span-8">
          {/* Badge removido conforme solicitação */}
          
          <h1 className="text-6xl md:text-9xl font-bold leading-[0.85] tracking-tighter mb-8 animate-reveal" style={{ animationDelay: '0.1s' }}>
            <span className="block text-slate-100">{t('hero.title1')}</span>
            <span className="block font-display italic text-accent opacity-90 mt-4">{t('hero.title1_suffix')}</span>
          </h1>

          <p className="max-w-2xl text-xl md:text-2xl text-slate-400 font-medium leading-relaxed mb-12 animate-reveal" style={{ animationDelay: '0.2s' }}>
            {t('hero.description')}
          </p>

          <div className="flex flex-wrap gap-6 items-center animate-reveal" style={{ animationDelay: '0.3s' }}>
            <button 
              onClick={onProjectsClick}
              className="px-10 py-5 bg-white text-dark font-black text-sm uppercase tracking-widest rounded-full hover:scale-105 active:scale-95 transition-all shadow-2xl hover:bg-accent hover:text-white"
            >
              {t('hero.viewPortfolio')}
            </button>
            
            <div className="flex gap-4">
              {[
                { icon: Github, href: "https://github.com/RonanP39" },
                { icon: Linkedin, href: "https://www.linkedin.com/in/ronanpereira/" },
                { icon: MessageCircle, href: "https://wa.me/5516981044494" }
              ].map((social, i) => (
                <a 
                  key={i} 
                  href={social.href} 
                  target="_blank" 
                  className="p-4 rounded-full border border-white/10 hover:border-accent hover:text-accent transition-all text-slate-400"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 hidden lg:block animate-reveal" style={{ animationDelay: '0.4s' }}>
          <div className="relative group">
            <div className="absolute inset-0 bg-accent/20 rounded-3xl blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            <div className="relative aspect-[3/4] rounded-3xl overflow-hidden border border-white/10 shadow-2xl glass-card">
              <img 
                src="https://github.com/RonanP39.png" 
                alt="Profile" 
                className="w-full h-full object-cover grayscale brightness-90 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000"
              />
              <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-dark to-transparent">
                <span className="text-4xl font-display italic text-white">Ronan P.</span>
                <span className="block text-[10px] uppercase tracking-[0.3em] text-accent mt-2">Architecting Futures</span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
