
import React, { useState, useEffect } from 'react';
import { Home, LayoutGrid, Newspaper, MessageSquare, Globe, ArrowUp } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface NavbarProps {
  onProjectsClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onProjectsClick }) => {
  const { language, setLanguage, t } = useLanguage();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 300);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { id: 'home', icon: Home, label: t('nav.about'), action: () => window.scrollTo({ top: 0, behavior: 'smooth' }) },
    { id: 'projects', icon: LayoutGrid, label: t('nav.portfolio'), action: onProjectsClick },
    { id: 'news', icon: Newspaper, label: t('nav.news'), action: () => document.getElementById('tech-intel')?.scrollIntoView({ behavior: 'smooth' }) },
    { id: 'feedback', icon: MessageSquare, label: t('nav.feedback'), action: () => document.getElementById('feedback')?.scrollIntoView({ behavior: 'smooth' }) },
  ];

  return (
    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] w-fit px-4">
      <div className="flex items-center gap-2 p-2 rounded-full glass-card border-white/10 shadow-2xl">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={item.action}
            className="group relative p-3 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-all"
            title={item.label}
          >
            <item.icon className="w-5 h-5" />
            <span className="absolute -top-12 left-1/2 -translate-x-1/2 px-2 py-1 bg-dark text-[10px] font-bold uppercase tracking-widest text-white rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none border border-white/10">
              {item.label}
            </span>
          </button>
        ))}
        
        <div className="w-px h-6 bg-white/10 mx-2"></div>

        <button
          onClick={() => setLanguage(language === 'en' ? 'pt' : 'en')}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full hover:bg-white/10 text-[10px] font-black uppercase text-accent"
        >
          <Globe className="w-4 h-4" />
          {language}
        </button>

        {scrolled && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="p-3 rounded-full bg-accent text-white ml-2 hover:scale-110 transition-transform shadow-lg shadow-accent/20"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
