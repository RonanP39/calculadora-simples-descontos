import React from 'react';
import { Star, Quote, ExternalLink } from 'lucide-react';

interface Review {
  name: string;
  rating: number;
  text: string;
  date: string;
}

export const Testimonials: React.FC = () => {
  const reviews: Review[] = [
    {
      name: "Ricardo Souza",
      rating: 5,
      text: "Levei meu carro para uma revisão geral e fui surpreendido pela honestidade. Diagnóstico preciso e preço justo.",
      date: "Há 2 meses"
    },
    {
      name: "Ana Paula Lima",
      rating: 5,
      text: "A melhor oficina de Franca! O atendimento é nota 10. Resolveram um barulho que ninguém achava.",
      date: "Há 1 mês"
    },
    {
      name: "Marcos Vinícius",
      rating: 5,
      text: "Oficina limpa, organizada e cumprem os prazos. O sistema de agendamento funciona muito bem.",
      date: "Há 3 semanas"
    }
  ];

  return (
    <section className="py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20 pointer-events-none">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-red-600 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 right-0 w-64 h-64 bg-blue-900 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <span className="text-red-500 font-bold tracking-wider uppercase text-sm">Feedback Real</span>
          <h2 className="mt-2 text-3xl md:text-4xl font-extrabold tracking-tight text-white">
            Quem conhece, confia na DLN
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {reviews.map((review, index) => (
            <div key={index} className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-8 border border-slate-700 hover:border-red-500/50 transition-colors duration-300 relative group">
              <Quote className="absolute top-6 right-6 h-10 w-10 text-slate-700 group-hover:text-red-500/20 transition-colors" />
              
              <div className="flex mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-red-500 fill-current" />
                ))}
              </div>

              <p className="text-gray-300 mb-6 italic leading-relaxed text-sm min-h-[80px]">
                "{review.text}"
              </p>

              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-red-500 to-red-700 flex items-center justify-center font-bold text-white text-sm">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">{review.name}</h4>
                  <span className="text-xs text-gray-500">{review.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a 
            href="https://www.google.com/maps/place//data=!4m2!3m1!1s0x94b0a71efe0b63cb:0x516e32af391b6219?source=g.page.m._"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-3 rounded-full border border-slate-600 text-base font-medium text-gray-300 hover:bg-white hover:text-slate-900 transition-all duration-300 hover:border-white"
          >
            Ver mais no Google
            <ExternalLink className="ml-2 h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
};