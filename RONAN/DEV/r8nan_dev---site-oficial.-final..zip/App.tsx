
import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Projects } from './components/Projects';
import { TechNews } from './components/TechNews';
import { Feedback } from './components/Feedback';
import { Footer } from './components/Footer';
import { SplashScreen } from './components/SplashScreen';
import { MarketTicker } from './components/MarketTicker';
import { TechStack } from './components/TechStack';

function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [currentView, setCurrentView] = useState<'home' | 'projects'>('home');

  const handleShowProjects = () => setCurrentView('projects');
  const handleShowHome = () => setCurrentView('home');

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#020617] relative overflow-x-hidden selection:bg-accent selection:text-dark">
      {/* Dynamic Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-900/10 rounded-full blur-[180px] animate-blob"></div>
        <div className="absolute bottom-[0%] right-[-10%] w-[50%] h-[50%] bg-indigo-900/10 rounded-full blur-[180px] animate-blob animation-delay-4000"></div>
        <div className="absolute top-[30%] left-[20%] w-[40%] h-[40%] bg-cyan-900/5 rounded-full blur-[150px] animate-blob animation-delay-2000"></div>
      </div>

      <div className="relative z-10">
        {currentView === 'home' ? (
          <>
            <Navbar onProjectsClick={handleShowProjects} />
            <Hero onProjectsClick={handleShowProjects} />
            <div className="py-0">
              <MarketTicker />
              <TechStack />
            </div>
            <TechNews />
            <Feedback />
            <Footer />
          </>
        ) : (
          <Projects onBack={handleShowHome} />
        )}
      </div>
    </div>
  );
}

export default App;
