import React, { useState, useRef, useEffect } from 'react';
import { Instagram, ChevronLeft, ChevronRight, Loader2, ExternalLink } from 'lucide-react';

// Interface para os dados vindos da API do Instagram
interface InstagramPost {
  id: string;
  media_url: string;
  permalink: string;
  caption?: string;
  media_type: 'IMAGE' | 'VIDEO' | 'CAROUSEL_ALBUM';
  thumbnail_url?: string; // Para vídeos
}

export const Gallery: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [posts, setPosts] = useState<InstagramPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // CONFIGURAÇÃO: Para tornar 100% real, o cliente precisaria gerar um token na Meta Developers
  // Como não temos o token, deixamos vazio para ativar o modo "Simulação"
  const INSTAGRAM_ACCESS_TOKEN = ''; 

  // Dados de Fallback (Simulação do Feed da DLN)
  // Usamos isso para garantir que o site tenha conteúdo bonito mesmo sem a API configurada
  const FALLBACK_FEED: InstagramPost[] = [
    {
      id: '1',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1486262715619-01b8c22971f5?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Dia de casa cheia na DLN! 🚗💨 Nossa equipe especializada pronta para cuidar do seu veículo. #DLNMecanica #OficinaPremium"
    },
    {
      id: '2',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Projeto de performance finalizado. O ronco desse motor ficou insano! 🔥 #Tuning #Performance #Dyno"
    },
    {
      id: '3',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Manutenção preventiva é segurança. Verificando freios e suspensão hoje. #SegurancaAutomotiva"
    },
    {
      id: '4',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1632823471565-1ec85c54c37f?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Diagnóstico computadorizado de precisão. Aqui não tem 'achismo', tem técnica! 💻🛠️"
    },
    {
      id: '5',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1503376763036-066120622c74?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Detalhes que fazem a diferença. Cuidado em cada peça. #MecanicaDePrecisao"
    },
    {
      id: '6',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Troca de óleo e filtros. O básico bem feito garante a vida útil do seu motor."
    },
    {
      id: '7',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1530906358829-e84b2769270f?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Upgrade de turbina nesse projeto especial. Vai vir forte! 🚀"
    },
    {
      id: '8',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Alinhamento 3D para garantir estabilidade e economia de pneus."
    },
    {
      id: '9',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1597762470488-387751f538c6?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "Finalizando mais uma semana abençoada. Obrigado pela confiança! 🙏"
    },
    {
      id: '10',
      media_type: 'IMAGE',
      media_url: "https://images.unsplash.com/photo-1507136566006-cfc505b114fc?auto=format&fit=crop&q=80&w=800",
      permalink: "https://www.instagram.com/oficina.dln/",
      caption: "BMW recebendo tratamento VIP na DLN hoje. Especialistas em importados."
    }
  ];

  useEffect(() => {
    const fetchInstagramPhotos = async () => {
      setLoading(true);
      
      // Se não tiver token configurado, usamos o fallback imediatamente
      if (!INSTAGRAM_ACCESS_TOKEN) {
        // Delay artificial para simular carregamento de API (UX)
        setTimeout(() => {
          setPosts(FALLBACK_FEED);
          setLoading(false);
        }, 800);
        return;
      }

      try {
        const response = await fetch(
          `https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,thumbnail_url,permalink&access_token=${INSTAGRAM_ACCESS_TOKEN}&limit=10`
        );

        if (!response.ok) {
          throw new Error('Falha ao buscar fotos');
        }

        const data = await response.json();
        setPosts(data.data);
      } catch (err) {
        console.error("Erro ao carregar Instagram:", err);
        setError(true);
        // Em caso de erro na API real, usamos o fallback para não quebrar o site
        setPosts(FALLBACK_FEED);
      } finally {
        setLoading(false);
      }
    };

    fetchInstagramPhotos();
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { current } = scrollRef;
      const scrollAmount = 320; 
      if (direction === 'left') {
        current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  };

  return (
    <section className="py-20 bg-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div className="text-left max-w-2xl">
            <h2 className="text-red-600 font-bold tracking-wide uppercase text-sm">Acompanhe nosso Dia a Dia</h2>
            <h3 className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Galeria da Oficina
            </h3>
            <p className="mt-4 text-xl text-gray-500">
              Confira os últimos projetos e serviços realizados pela equipe DLN.
            </p>
          </div>
          
          <a 
            href="https://www.instagram.com/oficina.dln/"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:flex items-center gap-2 text-red-600 font-semibold hover:text-red-700 transition-colors mt-4 md:mt-0 group"
          >
            <Instagram className="h-5 w-5 transition-transform group-hover:scale-110" />
            @oficina.dln
          </a>
        </div>

        {/* Carousel Container */}
        <div className="relative group">
          
          {loading ? (
            <div className="flex justify-center items-center h-[350px] w-full bg-gray-50 rounded-xl border border-gray-100">
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="h-8 w-8 text-red-600 animate-spin" />
                <span className="text-gray-400 font-medium">Carregando feed...</span>
              </div>
            </div>
          ) : (
            <>
              {/* Controls */}
              <button 
                onClick={() => scroll('left')}
                className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0 -ml-4 md:-ml-6 hover:bg-white hover:text-red-600"
                aria-label="Anterior"
              >
                <ChevronLeft className="h-6 w-6 text-gray-800" />
              </button>
              
              <button 
                onClick={() => scroll('right')}
                className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/90 p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0 -mr-4 md:-mr-6 hover:bg-white hover:text-red-600"
                aria-label="Próximo"
              >
                <ChevronRight className="h-6 w-6 text-gray-800" />
              </button>

              {/* Scrollable Area */}
              <div 
                ref={scrollRef}
                className="flex gap-6 overflow-x-auto pb-8 scrollbar-thin snap-x snap-mandatory"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                {posts.map((post) => (
                  <div 
                    key={post.id} 
                    className="flex-none w-[280px] md:w-[320px] snap-center"
                  >
                    <a 
                      href={post.permalink} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="block group/card"
                    >
                      <div className="relative aspect-square overflow-hidden rounded-xl shadow-md border border-gray-100">
                        <img 
                          src={post.media_type === 'VIDEO' && post.thumbnail_url ? post.thumbnail_url : post.media_url} 
                          alt={post.caption || 'Foto do Instagram DLN'}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover/card:scale-110"
                        />
                        
                        {/* Overlay with Caption */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover/card:opacity-100 transition-all duration-300 flex flex-col justify-end p-6">
                          <p className="text-white text-sm line-clamp-3 font-medium leading-relaxed">
                            {post.caption || 'Ver no Instagram'}
                          </p>
                          <div className="mt-3 flex items-center text-red-400 text-xs font-bold uppercase tracking-wider">
                            <span className="mr-1">Ver Post</span>
                            <ExternalLink className="h-3 w-3" />
                          </div>
                        </div>

                        {/* Icon Corner */}
                        <div className="absolute top-3 right-3 bg-black/20 backdrop-blur-sm p-2 rounded-full opacity-100 group-hover/card:opacity-0 transition-opacity duration-300">
                          <Instagram className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    </a>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        <div className="mt-4 text-center md:hidden">
           <a 
            href="https://www.instagram.com/oficina.dln/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-gray-300 rounded-md text-base font-medium text-gray-700 bg-white hover:bg-gray-50 w-full"
          >
            <Instagram className="h-5 w-5 text-red-600" />
            Ver mais no Instagram
          </a>
        </div>
      </div>
    </section>
  );
};