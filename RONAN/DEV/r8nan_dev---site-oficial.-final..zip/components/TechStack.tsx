
import React from 'react';
import { Smartphone, Bug, Zap, Laptop, Monitor, Terminal, GitBranch, Code2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const TechStack: React.FC = () => {
  const { t } = useLanguage();

  const coreStack = [
    { name: 'HTML5', src: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg' },
    { name: 'CSS3', src: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg' },
    { name: 'JS', src: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg' },
    { name: 'React', src: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg' },
    { name: 'TypeScript', src: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg' },
    { name: 'Tailwind', src: 'https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons/tailwindcss/tailwindcss-original.svg' }
  ];

  const expertises = [
    { icon: Smartphone, label: t('stack.responsive'), desc: 'Mobile-first fluid architecture' },
    { icon: Zap, label: t('stack.performance'), desc: 'Core Web Vitals specialist' },
    { icon: Bug, label: t('stack.testing'), desc: 'Robust unit & E2E strategies' },
    { icon: Terminal, label: t('stack.devtools'), desc: 'Deep browser inspection expertise' }
  ];

  return (
    <section className="py-32 px-6 bg-dark">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          
          <div>
            <span className="text-accent text-xs font-black uppercase tracking-[0.4em] mb-4 block">Engine Room</span>
            <h2 className="text-5xl font-bold mb-12 tracking-tight">Technical <span className="font-display italic">Proficiency</span></h2>
            
            <div className="grid grid-cols-3 gap-6">
              {coreStack.map(tech => (
                <div key={tech.name} className="group p-6 glass-card rounded-3xl flex flex-col items-center justify-center gap-4 hover:bg-white/5 transition-all">
                  <img src={tech.src} alt={tech.name} className="w-10 h-10 grayscale group-hover:grayscale-0 transition-all" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 group-hover:text-white">{tech.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <div className="space-y-8">
              {expertises.map((item, i) => (
                <div key={i} className="flex items-start gap-6 group">
                  <div className="mt-1 p-3 bg-white/5 rounded-2xl border border-white/10 group-hover:border-accent group-hover:text-accent transition-all text-slate-500">
                    <item.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-white mb-1 group-hover:text-accent transition-colors">{item.label}</h4>
                    <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
