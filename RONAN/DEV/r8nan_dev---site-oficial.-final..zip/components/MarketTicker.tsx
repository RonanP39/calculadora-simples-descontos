
import React, { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, Bitcoin, Euro, Activity } from 'lucide-react';

interface CoinData {
  code: string;
  bid: string;
  pctChange: string;
  name: string;
}

export const MarketTicker: React.FC = () => {
  const [data, setData] = useState<{ [key: string]: CoinData }>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMarket = async () => {
      try {
        const response = await fetch('https://economia.awesomeapi.com.br/last/USD-BRL,EUR-BRL,BTC-BRL');
        const json = await response.json();
        setData({
          USD: json.USDBRL,
          EUR: json.EURBRL,
          BTC: json.BTCBRL
        });
      } catch (error) {
        console.error("Market data fetch failed", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMarket();
    const interval = setInterval(fetchMarket, 60000);
    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (val: string, isCrypto = false) => {
    const num = parseFloat(val);
    if (isNaN(num)) return 'R$ 0,00';
    return isCrypto 
      ? num.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
      : num.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  if (loading) return (
    <div className="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-6">
      {[1, 2, 3].map(i => (
        <div key={i} className="h-32 rounded-[2rem] bg-white/5 animate-pulse border border-white/5"></div>
      ))}
    </div>
  );

  return (
    <section className="py-12 px-6 bg-dark relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-8 opacity-50">
          <Activity className="w-4 h-4 text-accent" />
          <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Market Intelligence Hub</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Object.values(data).map((coin: CoinData) => {
            const isUp = parseFloat(coin.pctChange) >= 0;
            const Icon = coin.code === 'USD' ? DollarSign : coin.code === 'EUR' ? Euro : Bitcoin;
            
            return (
              <div 
                key={coin.code} 
                className="group relative overflow-hidden rounded-[2rem] glass-card p-8 border border-white/5 hover:border-accent/30 transition-all duration-500"
              >
                {/* Background Glow Effect */}
                <div className="absolute -right-4 -top-4 w-24 h-24 bg-accent/5 rounded-full blur-2xl group-hover:bg-accent/10 transition-colors"></div>
                
                <div className="flex items-start justify-between relative z-10">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">
                      {coin.name.split('/')[0]}
                    </span>
                    <h4 className="text-3xl font-mono font-bold text-white tracking-tighter">
                      {formatCurrency(coin.bid, coin.code === 'BTC')}
                    </h4>
                  </div>
                  
                  <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-accent group-hover:scale-110 group-hover:bg-accent group-hover:text-white transition-all duration-500">
                    <Icon className="w-6 h-6" />
                  </div>
                </div>

                <div className="mt-6 flex items-center justify-between relative z-10">
                  <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold font-mono ${
                    isUp ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                  }`}>
                    {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    {coin.pctChange}%
                  </div>
                  
                  <span className="text-[8px] font-mono text-slate-600 uppercase tracking-widest">
                    Real-time update
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
