
import React, { useState, useEffect } from 'react';
import { Newspaper, Rss, ExternalLink, RefreshCcw, Loader2, Globe, Cpu, Terminal, ChevronRight } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { useLanguage } from '../contexts/LanguageContext';

interface NewsItem {
  title: string;
  summary: string;
  url: string;
  source: string;
}

export const TechNews: React.FC = () => {
  const { t, language } = useLanguage();
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const fetchNews = async () => {
    setLoading(true);
    setError(false);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = language === 'pt' 
        ? "Liste as 6 notícias de tecnologia mais importantes de hoje. Para cada uma, forneça um título, um resumo de 2 frases e o veículo de publicação. Use o Google Search para garantir atualidade."
        : "List the top 6 most important technology news from today. For each, provide a title, a 2-sentence summary, and the publisher name. Ground your response using Google Search.";
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });

      const textOutput = response.text || '';
      const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      
      const lines = textOutput.split('\n').filter(l => l.trim().length > 15);
      const parsedItems: NewsItem[] = [];

      // Grounding link extraction and pairing with text titles/summaries
      for (let i = 0; i < Math.min(6, grounding.length); i++) {
        const chunk = grounding[i];
        if (chunk.web) {
          parsedItems.push({
            title: chunk.web.title || (language === 'pt' ? `Notícia Tech ${i + 1}` : `Tech Update ${i + 1}`),
            summary: lines[i] || (language === 'pt' ? 'Detalhes disponíveis na fonte.' : 'Details available in source link.'),
            url: chunk.web.uri,
            source: chunk.web.title?.split(/[-|]/)[1]?.trim() || 'Global Intel'
          });
        }
      }

      setNews(parsedItems);
    } catch (err) {
      console.error('Failed to fetch grounded news:', err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [language]);

  return (
    <section id="tech-intel" className="py-24 px-6 relative overflow-hidden bg-[#050914] scroll-mt-24">
      {/* Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px] opacity-50 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 border-b border-white/5 pb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
               <Terminal className="h-5 w-5 text-accent" />
               <span className="text-[10px] font-mono text-accent uppercase tracking-widest">System_Feed: Live</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black text-white tracking-[-0.05em] uppercase">
              {t('news.title')} <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-400 to-slate-700">{t('news.subtitle')}</span>
            </h2>
          </div>

          <button 
            onClick={fetchNews}
            disabled={loading}
            className="mt-6 md:mt-0 flex items-center gap-3 px-5 py-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-accent/30 transition-all group disabled:opacity-50"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin text-accent" /> : <RefreshCcw className="h-4 w-4 text-slate-400 group-hover:text-accent group-active:rotate-180 transition-all" />}
            <span className="text-xs font-bold text-slate-300 group-hover:text-white uppercase tracking-wider">{t('news.retry').split(' ')[0]}</span>
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-60 rounded-xl bg-slate-900/30 border border-white/5 animate-pulse flex flex-col p-6 gap-4 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/10 to-transparent animate-shimmer"></div>
                <div className="flex justify-between">
                   <div className="h-3 w-20 bg-white/10 rounded"></div>
                   <div className="h-3 w-10 bg-white/10 rounded"></div>
                </div>
                <div className="h-5 w-3/4 bg-white/10 rounded mt-4"></div>
                <div className="h-4 w-full bg-white/5 rounded"></div>
                <div className="h-4 w-2/3 bg-white/5 rounded"></div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="rounded-2xl p-12 text-center border border-red-500/20 bg-red-500/5">
            <p className="text-red-400 font-mono text-sm mb-4">ERR_CONNECTION_REFUSED :: DATA_STREAM_BROKEN</p>
            <button onClick={fetchNews} className="text-accent hover:text-white font-bold uppercase text-xs tracking-widest border-b border-accent/30 hover:border-accent pb-1 transition-all">{t('news.retry')}</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {news.map((item, idx) => (
              <div 
                key={idx} 
                className="group relative flex flex-col bg-[#0b1221] rounded-xl border border-white/5 overflow-hidden hover:border-accent/40 transition-all duration-300 hover:shadow-[0_0_30px_-5px_rgba(56,189,248,0.15)] hover:-translate-y-1"
              >
                {/* Decoration Lines */}
                <div className="absolute top-0 right-0 w-8 h-8 border-t border-r border-white/10 rounded-tr-xl group-hover:border-accent transition-colors"></div>
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b border-l border-white/10 rounded-bl-xl group-hover:border-accent transition-colors"></div>
                
                <div className="p-6 flex flex-col h-full relative z-10">
                   <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                         <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse"></div>
                         <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">{item.source}</span>
                      </div>
                      <span className="text-[9px] font-mono text-slate-700">IDX_0{idx + 1}</span>
                   </div>

                   <h3 className="text-lg font-bold text-slate-100 mb-3 leading-snug group-hover:text-accent transition-colors line-clamp-2">
                     {item.title}
                   </h3>
                   
                   <p className="text-slate-400 text-xs leading-relaxed mb-6 line-clamp-3 font-medium opacity-80">
                     {item.summary}
                   </p>
                   
                   <div className="mt-auto pt-4 border-t border-white/5 flex justify-between items-center">
                      <span className="text-[10px] text-slate-600 font-mono">READ_TIME: ~2MIN</span>
                      <a 
                        href={item.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[10px] font-black text-white uppercase tracking-widest hover:text-accent transition-colors group/btn"
                      >
                        {t('news.readMore')}
                        <ChevronRight className="h-3 w-3 group-hover/btn:translate-x-1 transition-transform" />
                      </a>
                   </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
