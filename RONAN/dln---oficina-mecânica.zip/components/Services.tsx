import React from 'react';
import { Wrench, MoveHorizontal, Rocket, Cpu, Activity, ArrowUpCircle } from 'lucide-react';
import { ServiceItem } from '../types';

export const Services: React.FC = () => {
  const services: ServiceItem[] = [
    {
      title: 'Mecânica Geral',
      description: 'Manutenção completa: motor, freios, suspensão e sistemas eletrônicos.',
      icon: <Wrench className="h-6 w-6 text-white" />,
    },
    {
      title: 'Alinhamento 3D',
      description: 'Precisão milimétrica para garantir estabilidade e preservar seus pneus.',
      icon: <MoveHorizontal className="h-6 w-6 text-white" />,
    },
    {
      title: 'Alta Performance',
      description: 'Projetos de preparação Street ou Pista para extrair potência máxima.',
      icon: <Rocket className="h-6 w-6 text-white" />,
    },
    {
      title: 'Remap ECU/TCU',
      description: 'Reprogramação de software para otimização de torque e resposta.',
      icon: <Cpu className="h-6 w-6 text-white" />,
    },
    {
      title: 'Dinamômetro',
      description: 'Aferição real de potência em nosso Dynotech 720i próprio.',
      icon: <Activity className="h-6 w-6 text-white" />,
    },
    {
      title: 'Peças & Upgrades',
      description: 'Instalação de turbos, intakes e componentes de performance.',
      icon: <ArrowUpCircle className="h-6 w-6 text-white" />,
    },
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-red-600 font-bold tracking-wide uppercase text-sm">Nossos Serviços</span>
            <h2 className="mt-2 text-4xl font-extrabold text-slate-900 leading-tight">
              Soluções Automotivas <br/> de <span className="text-red-600 relative">
                Ponta a Ponta
                <svg className="absolute w-full h-2 bottom-0 left-0 text-red-200 -z-10" viewBox="0 0 100 10" preserveAspectRatio="none">
                  <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" />
                </svg>
              </span>
            </h2>
          </div>
          <p className="text-gray-500 max-w-sm text-right hidden md:block">
            Cuidamos do seu carro com a mesma paixão que você. Tecnologia e transparência em cada serviço.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="group bg-gray-50 rounded-xl p-8 transition-all duration-300 hover:bg-white hover:shadow-xl hover:-translate-y-2 border-t-4 border-transparent hover:border-red-600 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-5 transition-opacity">
                 {React.cloneElement(service.icon as React.ReactElement<any>, { className: "h-24 w-24 text-red-600" })}
              </div>

              <div className="w-12 h-12 rounded-lg bg-slate-900 flex items-center justify-center mb-6 shadow-lg shadow-slate-900/20 group-hover:bg-red-600 group-hover:shadow-red-600/30 transition-all duration-300">
                {service.icon}
              </div>
              
              <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
              <p className="text-gray-600 leading-relaxed text-sm">
                {service.description}
              </p>
              
              <div className="mt-6 pt-4 border-t border-gray-200 opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="text-red-600 text-sm font-bold flex items-center gap-1">
                  Saiba mais 
                  <ArrowUpCircle className="h-4 w-4 rotate-45" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};