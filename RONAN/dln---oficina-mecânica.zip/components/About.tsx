import React from 'react';
import { CheckCircle, Award, Settings } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <section className="py-24 bg-slate-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          {/* Text Side (Agora à esquerda) */}
          <div className="flex-1 order-2 lg:order-1">
            <div className="inline-block px-3 py-1 rounded bg-red-100 text-red-700 text-xs font-bold uppercase tracking-widest mb-4">
              Sobre a DLN
            </div>
            <h3 className="text-4xl font-extrabold text-slate-900 leading-tight mb-6">
              Mecânica de Precisão e <br/>
              <span className="text-red-600">Transparência Total</span>
            </h3>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed">
              Fundada com a missão de elevar o padrão dos serviços automotivos em Franca, a DLN combina experiência tradicional com diagnósticos digitais avançados.
            </p>
            <p className="text-base text-gray-600 mb-8 leading-relaxed">
              Não somos apenas trocadores de peças. Somos técnicos analíticos que buscam a raiz do problema para entregar a solução definitiva para o seu veículo.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <Award className="h-5 w-5 text-red-600" />
                  <h4 className="font-bold text-slate-900">Certificada</h4>
                </div>
                <p className="text-xs text-gray-500">Equipe treinada nas principais montadoras.</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                <div className="flex items-center gap-3 mb-2">
                  <Settings className="h-5 w-5 text-red-600" />
                  <h4 className="font-bold text-slate-900">Tecnologia</h4>
                </div>
                <p className="text-xs text-gray-500">Equipamentos de diagnóstico de ponta.</p>
              </div>
            </div>

            <div className="mt-8 flex items-center gap-2 text-sm font-medium text-slate-700">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span>Garantia estendida em todos os serviços</span>
            </div>
          </div>

          {/* Image Side (Agora à direita) */}
          <div className="flex-1 relative order-1 lg:order-2">
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border-8 border-white">
              <img 
                src="https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?q=80&w=1974&auto=format&fit=crop" 
                alt="Mecânico trabalhando" 
                className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
              />
            </div>
            
            {/* Elementos Decorativos */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-red-100 rounded-full blur-3xl -z-0"></div>
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-slate-200 rounded-full blur-3xl -z-0"></div>
            <div className="absolute bottom-8 -left-8 bg-slate-900 text-white p-6 rounded-2xl shadow-xl z-20 max-w-[200px] hidden md:block">
              <p className="text-3xl font-bold text-red-500 mb-1">100%</p>
              <p className="text-sm leading-tight text-gray-300">Compromisso com peças originais</p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};