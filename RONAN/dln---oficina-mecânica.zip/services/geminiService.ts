import { GoogleGenAI } from "@google/genai";

// Initialize the API client
// Note: In a production environment, ensure your API key is restricted or use a backend proxy.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
Você é o "Assistente Virtual DLN", um especialista automotivo experiente e amigável da oficina "DLN - Oficina Mecânica".
Seu objetivo é ajudar clientes a entenderem possíveis problemas em seus veículos com base em sintomas relatados (barulhos, luzes no painel, cheiros, sensações ao dirigir).

Diretrizes:
1. Fale sempre em Português do Brasil.
2. Seja cortês, profissional e direto.
3. Ao analisar um problema, dê possíveis causas (diagnóstico prévio), mas SEMPRE deixe claro que é necessário uma avaliação presencial na DLN para confirmação.
4. Nunca dê orçamentos de preços exatos, apenas estimativas de complexidade se for muito óbvio (ex: "é um reparo simples" ou "requer atenção complexa").
5. Se o usuário perguntar sobre agendamento, endereço ou telefone, forneça os dados da DLN (R. Floriano Peixoto, 1034 - Centro, Franca - SP, 14400-760, Tel: (16) 98244-4933).
6. Use formatação Markdown simples (negrito, listas) para facilitar a leitura.
7. O nome do seu cliente (proprietário da oficina) é importante, então fale com orgulho da "Equipe DLN".
`;

export const sendMessageToGemini = async (
  message: string,
  history: { role: 'user' | 'model'; text: string }[]
): Promise<string> => {
  try {
    // Convert history to the format expected by the SDK if needed, 
    // but for simple single-turn or stateless appearing chat, we can just append context
    // or use the chat feature properly. Let's use the model directly for simplicity in this context
    // or construct a prompt with history.
    
    // Constructing a chat-like prompt sequence manually ensures better control for this specific demo
    // or using the chat API. Let's use generateContent with history context for robust single calls.
    
    const contents = [
      ...history.map(h => ({
        role: h.role,
        parts: [{ text: h.text }]
      })),
      {
        role: 'user',
        parts: [{ text: message }]
      }
    ];

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    return response.text || "Desculpe, não consegui processar sua resposta no momento. Tente novamente.";
  } catch (error) {
    console.error("Error communicating with Gemini:", error);
    return "Estou com dificuldades técnicas momentâneas. Por favor, entre em contato conosco pelo telefone (16) 98244-4933.";
  }
};