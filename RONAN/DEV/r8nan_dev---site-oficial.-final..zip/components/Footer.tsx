import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ViewCounter } from './ViewCounter';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  const socialLinks = [
    { name: 'GitHub', href: 'https://github.com/RonanP39' },
    { name: 'LinkedIn', href: 'https://www.linkedin.com/in/ronanpereira/' },
    { name: 'WhatsApp', href: 'https://wa.me/5516981044494' },
    { name: 'Instagram',href: 'https://www.instagram.com/nerd.verso_oficial/?next=%2F' }
  ];

  return (
    <footer id="contact" className="bg-[#020617] border-t border-white/5 py-12 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          
          <div className="flex flex-col items-center md:items-start gap-4">
            <div className="text-center md:text-left">
              <span className="font-bold text-2xl tracking-tighter font-mono text-white flex items-center gap-2 justify-center md:justify-start">
                R8NAN<span className="text-accent">/DEV</span>
              </span>
              <p className="text-slate-500 text-sm mt-3 font-light">{t('footer.copyright')}</p>
            </div>
            
            {/* View Counter Component */}
            <ViewCounter />
          </div>
          
          <div className="flex gap-8">
             {socialLinks.map((item) => (
               <a 
                key={item.name} 
                href={item.href}
                target={item.href.startsWith('http') ? "_blank" : undefined}
                rel={item.href.startsWith('http') ? "noopener noreferrer" : undefined}
                className="text-slate-400 hover:text-accent text-sm font-medium transition-all duration-300 hover:-translate-y-1"
               >
                 {item.name}
               </a>
             ))}
          </div>
        </div>
      </div>
    </footer>
  );
};