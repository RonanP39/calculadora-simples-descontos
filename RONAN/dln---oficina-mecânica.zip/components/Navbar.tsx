import React, { useState, useEffect } from 'react';
import { Menu, X, Wrench } from 'lucide-react';

interface NavbarProps {
  onOpenChat: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenChat }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Início', href: '#home' },
    { name: 'Serviços', href: '#services' },
    { name: 'Sobre Nós', href: '#about' },
    { name: 'Galeria', href: '#gallery' },
    { name: 'Avaliações', href: '#testimonials' },
    { name: 'Contato', href: '#contact' },
  ];

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-slate-900/95 shadow-lg backdrop-blur-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          
          {/* Logo */}
          <div className="flex items-center">
            <div className="bg-red-600 p-2 rounded-lg mr-2 shadow-lg shadow-red-600/20">
              <Wrench className="h-6 w-6 text-white" />
            </div>
            <span className={`text-2xl font-bold tracking-tighter ${isScrolled ? 'text-white' : 'text-white'}`}>
              DLN <span className="text-red-500">Mecânica</span>
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-red-500 relative group ${isScrolled ? 'text-gray-200' : 'text-white'}`}
              >
                {link.name}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-600 transition-all group-hover:w-full"></span>
              </a>
            ))}
            <button
              onClick={onOpenChat}
              className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white px-6 py-2.5 rounded-lg font-bold transition-all duration-300 shadow-lg shadow-red-900/20 hover:shadow-red-600/40 transform hover:-translate-y-0.5"
            >
              Diagnóstico IA
            </button>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-white focus:outline-none hover:text-red-500 transition-colors">
              {isOpen ? <X className="h-8 w-8" /> : <Menu className="h-8 w-8" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-slate-900 border-t border-slate-800 absolute w-full shadow-2xl">
          <div className="px-4 pt-4 pb-6 space-y-2 sm:px-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block px-4 py-3 rounded-lg text-base font-medium text-white hover:text-red-400 hover:bg-slate-800 transition-colors border border-transparent hover:border-slate-700"
              >
                {link.name}
              </a>
            ))}
            <button
              onClick={() => {
                setIsOpen(false);
                onOpenChat();
              }}
              className="w-full text-left mt-4 bg-gradient-to-r from-red-600 to-red-700 text-white px-4 py-3 rounded-lg font-bold shadow-md hover:from-red-500 hover:to-red-600 transition-all flex items-center justify-between group"
            >
              <span>Diagnóstico IA</span>
              <Wrench className="h-5 w-5 opacity-70 group-hover:opacity-100 transition-opacity" />
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};