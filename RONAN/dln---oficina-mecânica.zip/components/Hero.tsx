import React from 'react';

interface HeroProps {
  onOpenChat: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenChat }) => {
  return (
    <div className="relative h-screen min-h-[700px] flex items-center overflow-hidden bg-slate-900">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1486262715619-01b8c22971f5?q=80&w=2070&auto=format&fit=crop" 
          alt="Oficina Mecânica Profissional"
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-20">
        <div className="max-w-2xl">
          
          <div className="bg-black/30 backdrop-blur-md p-8 md:p-10 rounded-3xl border border-white/10 shadow-2xl animate-fade-in-up">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-400 text-sm font-semibold mb-6">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              Tecnologia e Confiança
            </div>

            <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight mb-6 leading-tight drop-shadow-lg">
              Performance e <br/>
              Segurança para o <span className="text-red-500">Seu Carro</span>
            </h1>
            
            <p className="text-lg text-gray-300 mb-8 leading-relaxed border-l-4 border-red-600 pl-4">
              A DLN Mecânica une a expertise técnica com equipamentos de última geração. Do diagnóstico via IA à manutenção preventiva.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://wa.me/5516982444933" 
                target="_blank"
                rel="noopener noreferrer"
                className="group relative px-8 py-4 bg-red-600 text-white rounded-xl font-bold text-lg overflow-hidden transition-all duration-300 hover:bg-red-700 hover:shadow-lg hover:shadow-red-600/30 text-center flex items-center justify-center gap-2"
              >
                Agendar Revisão
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </a>
              <button 
                onClick={onOpenChat}
                className="px-8 py-4 bg-transparent border border-white/30 text-white rounded-xl font-bold text-lg hover:bg-white/10 transition-all text-center flex items-center justify-center gap-2"
              >
                Mecânico Virtual
              </button>
            </div>
          </div>

          <div className="mt-12 flex items-center gap-8 text-white/80">
             <div className="flex flex-col">
                <span className="text-3xl font-bold text-white">10+</span>
                <span className="text-sm text-gray-400">Anos de XP</span>
             </div>
             <div className="w-px h-10 bg-white/20"></div>
             <div className="flex flex-col">
                <span className="text-3xl font-bold text-white">5k+</span>
                <span className="text-sm text-gray-400">Clientes</span>
             </div>
             <div className="w-px h-10 bg-white/20"></div>
             <div className="flex flex-col">
                <span className="text-3xl font-bold text-white">4.9</span>
                <span className="text-sm text-gray-400">Avaliação</span>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};