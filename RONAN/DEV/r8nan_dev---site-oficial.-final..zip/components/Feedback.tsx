import React, { useState } from 'react';
import { Star, Send, User, MessageSquare, CheckCircle, Loader2, Briefcase } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const Feedback: React.FC = () => {
  const { t } = useLanguage();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setTimeout(() => setIsSubmitted(false), 5000);
    }, 1500);
  };

  return (
    <section id="feedback" className="py-24 px-6 relative overflow-hidden bg-dark">
      <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-accent/5 rounded-full blur-[100px]"></div>
      
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block text-[10px] font-bold tracking-[0.2em] text-accent uppercase mb-4">Testimonials</div>
          <h2 className="text-4xl md:text-6xl font-extrabold text-white tracking-tighter mb-4">
            {t('feedback.title')} <span className="opacity-40">{t('feedback.subtitle')}</span>
          </h2>
          <p className="text-slate-400 text-lg font-medium leading-relaxed max-w-xl mx-auto">
            {t('feedback.description')}
          </p>
        </div>

        <div className="glass-card rounded-[2.5rem] p-8 md:p-12 relative border border-white/5">
          {isSubmitted ? (
            <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in">
              <CheckCircle className="h-16 w-16 text-green-400 mb-6" />
              <h3 className="text-2xl font-bold text-white mb-2">{t('feedback.success')}</h3>
              <p className="text-slate-400">Your opinion helps maintain high quality standards.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Name Input */}
                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <User className="h-3 w-3" />
                    {t('feedback.name')}
                  </label>
                  <input
                    required
                    type="text"
                    className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-accent/50 transition-colors"
                  />
                </div>

                {/* Project Type Dropdown */}
                <div className="space-y-3">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                    <Briefcase className="h-3 w-3" />
                    {t('feedback.projectType')}
                  </label>
                  <select 
                    required
                    className="w-full bg-slate-900 border border-white/10 rounded-xl p-4 text-slate-300 focus:outline-none focus:border-accent/50 appearance-none transition-colors cursor-pointer"
                  >
                    <option value="frontend">{t('feedback.projectTypes.frontend')}</option>
                    <option value="ai">{t('feedback.projectTypes.ai')}</option>
                    <option value="fullstack">{t('feedback.projectTypes.fullstack')}</option>
                    <option value="consultancy">{t('feedback.projectTypes.consultancy')}</option>
                  </select>
                </div>
              </div>

              {/* Rating Section */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block">
                  {t('feedback.rating')}
                </label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      className="transition-transform hover:scale-110 active:scale-90"
                    >
                      <Star
                        className={`h-8 w-8 transition-colors duration-200 ${
                          star <= (hoverRating || rating)
                            ? 'fill-accent text-accent shadow-[0_0_15px_rgba(56,189,248,0.3)]'
                            : 'text-slate-700'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Message Input */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <MessageSquare className="h-3 w-3" />
                  {t('feedback.message')}
                </label>
                <textarea
                  required
                  rows={4}
                  className="w-full bg-slate-900/50 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-accent/50 transition-colors resize-none"
                />
              </div>

              <button
                disabled={isSubmitting || rating === 0}
                type="submit"
                className={`w-full py-5 rounded-2xl font-bold uppercase tracking-widest transition-all flex items-center justify-center gap-3 ${
                  isSubmitting || rating === 0
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
                    : 'bg-white text-dark hover:bg-accent border border-white shadow-[0_10px_30px_rgba(0,0,0,0.3)]'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    {t('feedback.processing')}
                  </>
                ) : (
                  <>
                    <Send className="h-5 w-5" />
                    {t('feedback.submit')}
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};