
import React, { useState } from 'react';
import { Music, X, Disc, Play, Pause, ChevronRight, Activity } from 'lucide-react';

export const MusicPlayer: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 left-6 z-40 flex flex-col items-start">
      {/* Enhanced Music Deck Container */}
      <div 
        className={`transition-all duration-700 cubic-bezier(0.16, 1, 0.3, 1) origin-bottom-left overflow-hidden rounded-[2rem] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.8)] border border-white/10 bg-[#050914]/80 backdrop-blur-3xl ${
          isOpen 
            ? 'w-[320px] h-[480px] opacity-100 scale-100 translate-y-0 translate-x-0 mb-6' 
            : 'w-[100px] h-0 opacity-0 scale-90 translate-y-8 -translate-x-4 pointer-events-none mb-0'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Deck Header */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-white/5">
             <div className="flex items-center gap-3">
                <div className="relative">
                  <Activity className="h-4 w-4 text-accent animate-pulse" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Live Audio Deck</span>
             </div>
             <button onClick={() => setIsOpen(false)} className="text-slate-500 hover:text-white transition-colors">
               <X className="h-4 w-4" />
             </button>
          </div>

          {/* Spotify Container */}
          <div className="flex-grow p-4">
             <div className="relative h-full w-full rounded-2xl overflow-hidden bg-black/40 group border border-white/5 shadow-inner">
                {/* Visualizer Mock */}
                <div className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none opacity-20 flex items-end gap-[2px] px-4 pb-4">
                   {[...Array(20)].map((_, i) => (
                     <div 
                        key={i} 
                        className="flex-1 bg-accent/50 rounded-full" 
                        style={{ 
                          height: `${Math.random() * 80 + 20}%`,
                          animation: `float ${1 + Math.random()}s ease-in-out infinite` 
                        }}
                      />
                   ))}
                </div>

                <iframe 
                  style={{ borderRadius: '16px' }} 
                  src="https://open.spotify.com/embed/playlist/4ePzEX1XqBi0iKTe6gmJDj?utm_source=generator&theme=0" 
                  width="100%" 
                  height="100%" 
                  frameBorder="0" 
                  allowFullScreen 
                  allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" 
                  loading="lazy"
                  title="Spotify Player"
                  className="w-full h-full relative z-10"
                />
             </div>
          </div>

          {/* Deck Status Bar */}
          <div className="px-6 py-4 bg-white/5 border-t border-white/5 flex items-center justify-between">
             <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-accent animate-pulse"></div>
                <span className="text-[10px] text-slate-500 font-mono tracking-tighter">BITRATE // 320kbps</span>
             </div>
             <ChevronRight className="h-3 w-3 text-slate-700" />
          </div>
        </div>
      </div>

      {/* Modernized Floating Controller */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`group relative flex items-center gap-3 pr-6 pl-4 h-14 rounded-2xl shadow-2xl transition-all duration-500 cubic-bezier(0.16, 1, 0.3, 1) hover:scale-105 active:scale-95 border ${
          isOpen 
            ? 'bg-accent text-dark border-accent ring-4 ring-accent/20' 
            : 'bg-[#0f172a]/80 backdrop-blur-xl text-accent border-white/10 hover:border-accent/40'
        }`}
        aria-label="Toggle Dashboard Audio"
      >
        {/* Disc Spinner Icon */}
        <div className={`relative ${isOpen ? 'animate-spin-slow' : 'group-hover:rotate-12 transition-transform duration-500'}`}>
           <div className={`absolute inset-0 bg-accent/40 blur-md rounded-full transition-opacity duration-1000 ${isOpen ? 'opacity-100' : 'opacity-0'}`}></div>
           <Disc className={`w-6 h-6 relative z-10 ${isOpen ? 'text-dark' : 'text-accent'}`} />
        </div>

        {/* Text Label */}
        <div className="flex flex-col items-start leading-none">
          <span className={`text-[10px] font-black uppercase tracking-widest mb-0.5 ${isOpen ? 'text-dark/60' : 'text-slate-500'}`}>
            {isOpen ? 'Close' : 'Media'}
          </span>
          <span className={`text-xs font-bold font-mono ${isOpen ? 'text-dark' : 'text-slate-200'}`}>
            DASHBOARD_SOUND
          </span>
        </div>

        {/* State Indicators */}
        <div className={`flex gap-1 ml-2 transition-all duration-500 ${isOpen ? 'opacity-0 scale-0' : 'opacity-100'}`}>
           <div className="w-1 h-3 bg-accent/50 rounded-full animate-[float_1s_infinite]"></div>
           <div className="w-1 h-4 bg-accent/80 rounded-full animate-[float_1.2s_infinite]"></div>
           <div className="w-1 h-2 bg-accent/30 rounded-full animate-[float_0.8s_infinite]"></div>
        </div>
      </button>
    </div>
  );
};
