import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { About } from './components/About';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ChatAssistant } from './components/ChatAssistant';
import { Testimonials } from './components/Testimonials';
import { Gallery } from './components/Gallery';

const App: React.FC = () => {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar onOpenChat={() => setIsChatOpen(true)} />
      
      <main className="flex-grow">
        <div id="home">
          <Hero onOpenChat={() => setIsChatOpen(true)} />
        </div>
        
        <div id="services">
          <Services />
        </div>
        
        <div id="about">
          <About />
        </div>

        <div id="gallery">
          <Gallery />
        </div>

        <div id="testimonials">
          <Testimonials />
        </div>
        
        <div id="contact">
          <Contact />
        </div>
      </main>

      <Footer />

      {/* Floating Chat Button (if chat is closed) */}
      {!isChatOpen && (
        <button
          onClick={toggleChat}
          className="fixed bottom-6 right-6 z-40 bg-red-600 hover:bg-red-700 text-white p-4 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 flex items-center justify-center group"
          aria-label="Abrir Assistente Virtual"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-300 whitespace-nowrap font-medium">
            Assistente Virtual
          </span>
        </button>
      )}

      {/* Chat Component */}
      <ChatAssistant isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </div>
  );
};

export default App;