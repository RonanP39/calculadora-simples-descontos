export interface Project {
  id: string;
  title: string;
  description: string;
  tags: string[];
  imageUrl: string;
  link?: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export enum ImageEditorStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export enum EditorMode {
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
}

export interface GeneratedImage {
  imageUrl: string;
  prompt: string;
}
