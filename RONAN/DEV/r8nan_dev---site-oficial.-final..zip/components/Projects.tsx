
import React from 'react';
import { ArrowUpRight, Github, Layers, Zap, Globe, Smartphone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface ProjectsProps {
  onBack?: () => void;
}

export const Projects: React.FC<ProjectsProps> = ({ onBack }) => {
  const { t } = useLanguage();

  const projects = [
    {
      id: '1',
      title: 'E-Commerce Analytics',
      description: 'Production-grade enterprise dashboard.',
      tags: ['D3.js', 'WebSocket'],
      imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800',
      size: 'large'
    },
    {
      id: '2',
      title: 'Neural Chat UI',
      description: 'AI-driven messaging system.',
      tags: ['Gemini', 'Edge'],
      imageUrl: 'https://picsum.photos/seed/chat/800/600',
      size: 'small'
    },
    {
      id: '3',
      title: 'Asset Manager',
      description: 'Cloud orchestration.',
      tags: ['Next.js', 'AWS'],
      imageUrl: 'https://picsum.photos/seed/cloud/800/600',
      size: 'medium'
    },
    {
      id: '4',
      title: 'Performance Core',
      description: 'Optimization tool.',
      tags: ['Performance', 'Core'],
      imageUrl: 'https://picsum.photos/seed/perf/800/600',
      size: 'small'
    }
  ];

  return (
    <section className="min-h-screen py-32 px-6 bg-dark">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20">
          <div>
            <h2 className="text-6xl md:text-8xl font-bold tracking-tighter mb-4">
              {t('projects.title')} <span className="font-display italic text-accent">{t('projects.work')}</span>
            </h2>
            <p className="max-w-xl text-slate-400 text-lg">{t('projects.description')}</p>
          </div>
          {onBack && (
            <button onClick={onBack} className="mt-8 md:mt-0 text-slate-500 hover:text-white uppercase text-xs font-black tracking-widest border-b border-white/10 pb-2">
              Back to Home
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-2 gap-6 h-[800px]">
          {projects.map((p, i) => (
            <div 
              key={p.id}
              className={`relative overflow-hidden rounded-[2.5rem] glass-card group ${
                p.size === 'large' ? 'md:col-span-2 md:row-span-2' : 
                p.size === 'medium' ? 'md:col-span-2' : ''
              }`}
            >
              <img src={p.imageUrl} alt={p.title} className="absolute inset-0 w-full h-full object-cover opacity-20 group-hover:scale-110 group-hover:opacity-40 transition-all duration-700" />
              <div className="absolute inset-0 bg-gradient-to-t from-dark/90 to-transparent"></div>
              
              <div className="relative h-full p-10 flex flex-col justify-end">
                <div className="mb-auto flex justify-between items-start">
                   <div className="p-3 bg-white/5 rounded-2xl border border-white/10 text-accent">
                      {i === 0 ? <Layers /> : <Zap />}
                   </div>
                   <ArrowUpRight className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                
                <h3 className="text-3xl font-bold text-white mb-4">{p.title}</h3>
                <div className="flex flex-wrap gap-2">
                  {p.tags.map(tag => (
                    <span key={tag} className="px-3 py-1 bg-white/5 border border-white/5 rounded-lg text-[9px] font-black uppercase text-slate-500 tracking-wider">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
