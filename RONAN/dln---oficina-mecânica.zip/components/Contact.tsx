import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export const Contact: React.FC = () => {
  return (
    <section className="bg-slate-900 text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          <div>
            <h2 className="text-red-500 font-bold tracking-wide uppercase text-sm mb-2">Fale Conosco</h2>
            <h3 className="text-3xl font-extrabold mb-8">Onde Estamos</h3>
            <p className="text-gray-400 mb-10 text-lg">
              Venha tomar um café conosco e faça um orçamento sem compromisso. Estamos prontos para atender você e seu veículo.
            </p>

            <div className="space-y-6">
              <div className="flex items-start">
                <MapPin className="h-6 w-6 text-red-500 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-lg">Endereço</h4>
                  <p className="text-gray-400">R. Floriano Peixoto, 1034</p>
                  <p className="text-gray-400">Centro, Franca - SP, 14400-760</p>
                </div>
              </div>

              <div className="flex items-start">
                <Phone className="h-6 w-6 text-red-500 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-lg">Telefone & WhatsApp</h4>
                  <p className="text-gray-400">(16) 98244-4933</p>
                </div>
              </div>

              <div className="flex items-start">
                <Mail className="h-6 w-6 text-red-500 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-lg">Email</h4>
                  <p className="text-gray-400">contato@dlnmecanica.com.br</p>
                </div>
              </div>

              <div className="flex items-start">
                <Clock className="h-6 w-6 text-red-500 mr-4 mt-1" />
                <div>
                  <h4 className="font-bold text-lg">Horário de Funcionamento</h4>
                  <p className="text-gray-400">Seg - Sex: 08:30 - 18:00</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-800 p-2 rounded-xl h-[400px] lg:h-auto min-h-[400px]">
             <iframe 
               width="100%" 
               height="100%" 
               className="rounded-lg w-full h-full object-cover"
               frameBorder="0" 
               title="Mapa DLN Mecânica"
               scrolling="no" 
               src="https://maps.google.com/maps?q=R.+Floriano+Peixoto,+1034+-+Centro,+Franca+-+SP,+14400-760&t=&z=15&ie=UTF8&iwloc=&output=embed"
             ></iframe>
          </div>

        </div>
      </div>
    </section>
  );
};