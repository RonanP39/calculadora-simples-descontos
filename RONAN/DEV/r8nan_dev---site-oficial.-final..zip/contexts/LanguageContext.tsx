
import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'pt';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    nav: {
      about: 'About Me',
      portfolio: 'Selected Work',
      contact: 'Contact',
      feedback: 'Client Feedback',
      news: 'Tech Intel'
    },
    hero: {
      badge: 'Contact for Quotes !',
      title1: 'R8NAN/DEV',
      title1_suffix: 'Front-End Developer',
      title2: 'Solutions Architect',
      description: 'More than 5 years as a high-performance Front-End Developer. I connect complex backend logic to pixel-perfect, intuitive user experiences, using modern AI-driven workflows.',
      viewPortfolio: 'View Portfolio',
      tryDemo: 'Enter AI Lab',
      clickToFlip: 'Click to reveal bio'
    },
    stack: {
      title: 'Core Technologies & Tools',
      responsive: 'Responsive Design',
      testing: 'Testing & Debug',
      devtools: 'Browser DevTools',
      performance: 'Web Performance',
    },
    projects: {
      title: 'Selected',
      work: 'Works',
      description: 'Architecting scalable digital products with a focus on performance, accessibility, and cutting-edge interaction design.',
    },
    news: {
      title: 'Daily Tech',
      subtitle: 'Intelligence',
      poweredBy: 'Real-time Search Grounding',
      readMore: 'View Source',
      loading: 'Scouring global clusters for updates...',
      error: 'Data retrieval timeout.',
      retry: 'Retry Fetch'
    },
    feedback: {
      title: 'Client',
      subtitle: 'Feedback',
      description: 'Leave your impressions about my high-performance methodology and deliverables.',
      name: 'Full Name',
      projectType: 'Project Type',
      projectTypes: {
        frontend: 'Front-End UI/UX',
        ai: 'AI Integration',
        fullstack: 'Full-Stack Solution',
        consultancy: 'Technical Consultancy'
      },
      rating: 'Experience Rating',
      message: 'Your Review',
      submit: 'Send Feedback',
      success: 'Feedback sent successfully! Thank you for your partnership.',
      processing: 'Sending to Cloud...'
    },
    footer: {
      copyright: '© 2025 R8NAN Front-End Developer. Crafted with intent.',
      views: 'Total Views',
    },
  },
  pt: {
    nav: {
      about: 'Sobre mim',
      portfolio: 'Projetos',
      contact: 'Contato',
      feedback: 'Depoimentos',
      news: 'Radar Tech'
    },
    hero: {
      badge: 'Contato para Orçamentos !',
      title1: 'R8NAN/DEV',
      title1_suffix: 'Desenvolvedor Front-End',
      title2: 'Arquiteto de Soluções',
      description: 'Há mais de 5 anos atuando como Desenvolvedor Front-End de alto desempenho. Conecto lógicas complexas de backend a experiências de usuário intuitivas e pixel-perfect, utilizando fluxos de trabalho modernos potencializados por IA.',
      viewPortfolio: 'Ver Portfólio',
      tryDemo: 'Entrar no Lab IA',
      clickToFlip: 'Clique para ver bio'
    },
    stack: {
      title: 'Arsenal Tecnológico',
      responsive: 'Design Responsivo',
      testing: 'Testes & Depuração',
      devtools: 'DevTools Navegador',
      performance: 'Desempenho Web',
    },
    projects: {
      title: 'Trabalhos',
      work: 'Selecionados',
      description: 'Arquitetando produtos digitais escaláveis com foco em performance, acessibilidade e design de interação de ponta.',
    },
    news: {
      title: 'Radar',
      subtitle: 'Tecnológico',
      poweredBy: 'Grounding de busca em tempo real',
      readMore: 'Ler Matéria',
      loading: 'Varrendo clusters globais por novidades...',
      error: 'Timeout na recuperação de dados.',
      retry: 'Tentar Novamente'
    },
    feedback: {
      title: 'Feedback',
      subtitle: 'de Clientes',
      description: 'Deixe suas impressões sobre minha metodologia de alto desempenho e entregas.',
      name: 'Nome Completo',
      projectType: 'Tipo de Projeto',
      projectTypes: {
        frontend: 'Interface UI/UX',
        ai: 'Integração de IA',
        fullstack: 'Solução Completa',
        consultancy: 'Consultoria Técnica'
      },
      rating: 'Avaliação da Experiência',
      message: 'Seu Comentário',
      submit: 'Enviar Depoimento',
      success: 'Feedback enviado com sucesso! Obrigado pela parceria.',
      processing: 'Enviando para Nuvem...'
    },
    footer: {
      copyright: '© 2025 R8NAN Front-End & Especialista em IA. Criado com propósito.',
      views: 'Visualizações',
    },
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('pt');

  const t = (key: string) => {
    const keys = key.split('.');
    let value: any = translations[language];
    for (const k of keys) {
      if (value && value[k]) {
        value = value[k];
      } else {
        return key;
      }
    }
    return typeof value === 'string' ? value : key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
