import React, { useEffect, useState } from 'react';
import { Eye, Activity } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const ViewCounter: React.FC = () => {
  const [count, setCount] = useState<number>(0);
  const { t } = useLanguage();

  useEffect(() => {
    // Base views to simulate existing traffic (e.g., starting at 12,400)
    const BASE_VIEWS = 12450;
    
    // Check localStorage for previous visits
    const storedVisits = localStorage.getItem('r8nan_portfolio_visits');
    const visitCount = storedVisits ? parseInt(storedVisits) : 0;

    // Use sessionStorage to only increment once per session (tab open)
    // This prevents incrementing on every page refresh
    const hasVisitedSession = sessionStorage.getItem('r8nan_session_logged');

    let newCount = visitCount;

    if (!hasVisitedSession) {
      newCount = visitCount + 1;
      localStorage.setItem('r8nan_portfolio_visits', newCount.toString());
      sessionStorage.setItem('r8nan_session_logged', 'true');
    }

    // Animate the number counting up slightly
    const totalViews = BASE_VIEWS + newCount;
    let start = totalViews - 50;
    
    const timer = setInterval(() => {
      start += 1;
      setCount(start);
      if (start >= totalViews) clearInterval(timer);
    }, 20);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/50 border border-slate-800 backdrop-blur-sm shadow-sm group hover:border-accent/30 transition-colors duration-300">
      <div className="relative">
        <div className="absolute inset-0 bg-accent/20 blur-sm rounded-full animate-pulse"></div>
        <Eye className="h-3.5 w-3.5 text-accent relative z-10" />
      </div>
      
      <div className="flex flex-col items-start leading-none">
        <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-0.5">
          {t('footer.views')}
        </span>
        <span className="font-mono text-sm font-bold text-slate-300 group-hover:text-white transition-colors">
          {count.toLocaleString()}
        </span>
      </div>
    </div>
  );
};