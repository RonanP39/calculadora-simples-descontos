
import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

const CODE_SNIPPETS = [
  '<div class="portfolio">',
  '  <h1 class="glow">R8NAN</h1>',
  '  <script>',
  '    init_AI_Agent(gemini-2.5);',
  '  </script>',
  '</div>',
  '// Initializing neural link...',
  'const dev = new WebSpecialist();',
  'dev.level = "Senior";',
];

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [show, setShow] = useState(false);
  const [step, setStep] = useState(0); // 0: Coding, 1: Brand Glitch, 2: Welcome
  const [codeIndex, setCodeIndex] = useState(0);

  useEffect(() => {
    // Stage 0: Type code snippets
    const codeTimer = setInterval(() => {
      setCodeIndex((prev) => {
        if (prev < CODE_SNIPPETS.length - 1) return prev + 1;
        clearInterval(codeTimer);
        return prev;
      });
    }, 150);

    // Timeline for steps
    const step1Timer = setTimeout(() => {
      setStep(1); // Show Brand Glitch
      setShow(true);
    }, 1800);

    const step2Timer = setTimeout(() => {
      setShow(false); // Fade brand
    }, 3200);

    const step3Timer = setTimeout(() => {
      setStep(2); // Show Welcome
      setShow(true);
    }, 3600);

    const finishTimer = setTimeout(() => {
      setShow(false);
    }, 5200);

    const exitTimer = setTimeout(() => {
      onComplete();
    }, 5800);

    return () => {
      clearInterval(codeTimer);
      clearTimeout(step1Timer);
      clearTimeout(step2Timer);
      clearTimeout(step3Timer);
      clearTimeout(finishTimer);
      clearTimeout(exitTimer);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#020617] overflow-hidden">
      {/* Background Neural Grid */}
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(rgba(56,189,248,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(56,189,248,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>

      <div className="relative z-10 w-full max-w-lg px-6">
        {step === 0 && (
          <div className="font-mono text-accent text-sm space-y-1">
            {CODE_SNIPPETS.slice(0, codeIndex + 1).map((line, i) => (
              <div key={i} className="animate-fade-in flex">
                <span className="text-slate-700 mr-4 select-none">{(i + 1).toString().padStart(2, '0')}</span>
                <span className={line.startsWith('//') ? 'text-slate-500 italic' : ''}>{line}</span>
              </div>
            ))}
            <div className="w-2 h-4 bg-accent animate-pulse inline-block ml-1 align-middle"></div>
          </div>
        )}

        {step === 1 && (
          <div 
            className={`text-center transition-all duration-700 transform ${
              show ? 'opacity-100 scale-100' : 'opacity-0 scale-95 blur-md'
            }`}
          >
            <h1 className="text-5xl md:text-8xl font-black text-white font-mono tracking-tighter relative inline-block animate-glitch">
              R8NAN<span className="text-accent">/DEV</span>
              <div className="absolute top-0 left-0 w-full h-full text-red-500 opacity-30 animate-glitch -z-10 blur-sm">R8NAN/DEV</div>
              <div className="absolute top-0 left-0 w-full h-full text-blue-500 opacity-30 animate-glitch-reverse -z-10 blur-sm">R8NAN/DEV</div>
            </h1>
            <p className="mt-4 text-[10px] text-accent font-mono tracking-[0.5em] uppercase opacity-60">System initialized</p>
          </div>
        )}

        {step === 2 && (
          <div 
            className={`text-center transition-all duration-1000 transform ${
              show ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 blur-sm'
            }`}
          >
            <h2 className="text-2xl md:text-4xl font-light text-slate-200 tracking-[0.2em] uppercase leading-relaxed">
              Bem-Vindo(a) <br />
              <span className="text-accent font-bold mt-2 inline-block animate-pulse-soft">Welcome</span>
            </h2>
          </div>
        )}
      </div>

      {/* Dynamic Scanline */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-accent/5 to-transparent h-20 w-full top-[-100%] animate-shimmer opacity-20"></div>
    </div>
  );
};
