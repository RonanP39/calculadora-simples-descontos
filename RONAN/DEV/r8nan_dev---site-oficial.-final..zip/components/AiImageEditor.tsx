
import React, { useState, useRef, useEffect } from 'react';
import { Upload, Sparkles, Loader2, Image as ImageIcon, Wand2, Download, AlertCircle, Video, Play, Key, CheckCircle2, Command, Settings2, Cpu, Volume2, VolumeX, Terminal, Zap, Hash, Box } from 'lucide-react';
import { editImageWithGemini, generatePromoVideo } from '../services/geminiService';
import { ImageEditorStatus, EditorMode } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

const LOADING_STEPS = {
  en: {
    [EditorMode.IMAGE]: [
      "Initializing Neural Tensors...",
      "Parsing Semantic Context...",
      "Optimizing Latent Space...",
      "Synthesizing Pixel Arrays...",
      "Refining High-Frequency Details...",
      "Finalizing Output Buffer..."
    ],
    [EditorMode.VIDEO]: [
      "Allocating Veo Compute Nodes...",
      "Analyzing Temporal Coherence...",
      "Generating Keyframe Sequence...",
      "Interpolating Motion Vectors...",
      "Rendering Physics Simulation...",
      "Denoising Temporal Artifacts...",
      "Encoding MP4 Stream...",
      "Finalizing Render..."
    ]
  },
  pt: {
    [EditorMode.IMAGE]: [
      "Inicializando Tensores Neurais...",
      "Analisando Contexto Semântico...",
      "Otimizando Espaço Latente...",
      "Sintetizando Arrays de Pixels...",
      "Refinando Detalhes de Alta Frequência...",
      "Finalizando Buffer de Saída..."
    ],
    [EditorMode.VIDEO]: [
      "Alocando Nós de Computação Veo...",
      "Analisando Coerência Temporal...",
      "Gerando Sequência de Keyframes...",
      "Interpolando Vetores de Movimento...",
      "Renderizando Simulação Física...",
      "Removendo Artefatos Temporais...",
      "Codificando Stream MP4...",
      "Finalizando Renderização..."
    ]
  }
};

const SUGGESTED_PROMPTS = {
  en: {
    [EditorMode.IMAGE]: [
      "Apply cyberpunk color grading",
      "Add futuristic neon skyline in background",
      "3D Pixar animation style transformation",
      "Turn night into daylight"
    ],
    [EditorMode.VIDEO]: [
      "Cinematic drone shot over neon Tokyo at night",
      "Liquid gold fluid simulation splash",
      "Floating through cosmic nebula cloud",
      "Cyberpunk street racing POV 60fps"
    ]
  },
  pt: {
    [EditorMode.IMAGE]: [
      "Aplicar gradação de cor cyberpunk",
      "Adicionar skyline neon futurista ao fundo",
      "Transformação para estilo animação 3D Pixar",
      "Transformar noite em dia claro"
    ],
    [EditorMode.VIDEO]: [
      "Drone shot cinematográfico sobre Tokyo neon à noite",
      "Splash de simulação de fluido de ouro líquido",
      "Flutuando através de uma nuvem cósmica nebulosa",
      "POV corrida de rua cyberpunk 60fps"
    ]
  }
};

export const AiImageEditor: React.FC = () => {
  const [mode, setMode] = useState<EditorMode>(EditorMode.IMAGE);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedMimeType, setSelectedMimeType] = useState<string>('image/jpeg');
  const [prompt, setPrompt] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [status, setStatus] = useState<ImageEditorStatus>(ImageEditorStatus.IDLE);
  const [generatedMedia, setGeneratedMedia] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingStep, setLoadingStep] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const { t, language } = useLanguage();

  const playSound = (type: 'upload' | 'start' | 'success') => {
    if (isMuted) return;
    
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    const ctx = audioCtxRef.current;
    if (ctx.state === 'suspended') ctx.resume();

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;

    switch (type) {
      case 'upload':
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(110, now + 0.1);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
        break;
      case 'start':
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.linearRampToValueAtTime(880, now + 0.3);
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
        break;
      case 'success':
        [523.25, 659.25, 783.99].forEach((freq, i) => {
          const o = ctx.createOscillator();
          const g = ctx.createGain();
          o.connect(g);
          g.connect(ctx.destination);
          o.frequency.setValueAtTime(freq, now + i * 0.1);
          g.gain.setValueAtTime(0.05, now + i * 0.1);
          g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.2);
          o.start(now + i * 0.1);
          o.stop(now + i * 0.1 + 0.2);
        });
        break;
    }
  };

  const createDemoSketch = (): string => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 512, 512);

    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    for(let i=0; i<10; i++) {
        ctx.beginPath();
        ctx.arc(256, 256, 20 * i, 0, Math.PI * 2);
        ctx.stroke();
    }
    
    ctx.fillStyle = '#6366f1';
    ctx.beginPath();
    ctx.moveTo(256, 256);
    ctx.lineTo(512, 0);
    ctx.lineTo(512, 512);
    ctx.fill();

    return canvas.toDataURL('image/png');
  };

  useEffect(() => {
    const handleDemoTrigger = () => {
      setMode(EditorMode.IMAGE);
      const sketch = createDemoSketch();
      setSelectedImage(sketch);
      setSelectedMimeType('image/png');
      setPrompt(t('ai.demoPrompt'));
      setStatus(ImageEditorStatus.IDLE);
      setGeneratedMedia(null);
      setError(null);
      document.getElementById('ai-demo')?.scrollIntoView({ behavior: 'smooth' });
    };

    window.addEventListener('trigger-ai-demo', handleDemoTrigger);
    return () => window.removeEventListener('trigger-ai-demo', handleDemoTrigger);
  }, [t]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (status === ImageEditorStatus.LOADING) {
      setLoadingProgress(0);
      setLoadingStep(0);
      
      const duration = mode === EditorMode.IMAGE ? 8000 : 45000; 
      const updateInterval = 100;
      
      const currentSteps = LOADING_STEPS[language as 'en' | 'pt'][mode];
      const totalSteps = currentSteps.length;
      
      let elapsed = 0;
      
      interval = setInterval(() => {
        elapsed += updateInterval;
        let progress = (elapsed / duration) * 100;
        if (progress > 95) progress = 95;
        
        setLoadingProgress(progress);
        const stepIndex = Math.floor((progress / 100) * totalSteps);
        setLoadingStep(Math.min(stepIndex, totalSteps - 1));
        
      }, updateInterval);
    }
    return () => clearInterval(interval);
  }, [status, mode, language]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { 
        setError(t('ai.fileLimit'));
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setSelectedImage(result); 
        setSelectedMimeType(file.type);
        setGeneratedMedia(null);
        setError(null);
        setStatus(ImageEditorStatus.IDLE);
        playSound('upload');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleKeySelection = async () => {
    try {
      await (window as any).aistudio.openSelectKey();
    } catch (e) {
      console.error("Failed to open key selector", e);
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    if (mode === EditorMode.IMAGE && !selectedImage) return;

    setStatus(ImageEditorStatus.LOADING);
    setError(null);
    setGeneratedMedia(null);
    playSound('start');

    try {
      if (mode === EditorMode.IMAGE) {
        if (!selectedImage) return;
        const base64Data = selectedImage.split(',')[1];
        const resultImageUrl = await editImageWithGemini(base64Data, selectedMimeType, prompt);
        setGeneratedMedia(resultImageUrl);
      } else {
        const hasKey = await (window as any).aistudio.hasSelectedApiKey();
        if (!hasKey) {
          await (window as any).aistudio.openSelectKey();
        }

        const resultVideoUrl = await generatePromoVideo(prompt);
        setGeneratedMedia(resultVideoUrl);
      }
      setStatus(ImageEditorStatus.SUCCESS);
      playSound('success');
    } catch (err: any) {
      setError(err.message || 'Processing Protocol Failed.');
      setStatus(ImageEditorStatus.ERROR);
    }
  };

  const handleSuggestionClick = (s: string) => {
    setIsTyping(true);
    setPrompt(s);
    setTimeout(() => setIsTyping(false), 500);
  };

  const getLoadingText = () => {
    const steps = LOADING_STEPS[language as 'en' | 'pt'][mode];
    return steps[loadingStep] || steps[steps.length - 1];
  };

  return (
    <section id="ai-demo" className="py-32 relative overflow-hidden bg-[#050914] scroll-mt-24">
      {/* Precision Background Grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(56,189,248,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(56,189,248,0.03)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Intelligence Hub Header */}
        <div className="text-center mb-20 animate-fade-in">
          <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-accent/10 border border-accent/20 text-accent text-[10px] font-mono font-bold tracking-[0.3em] uppercase mb-8">
            <Cpu className="h-4 w-4" />
            {t('ai.badge')}
          </div>
          <h2 className="text-5xl md:text-7xl font-extrabold text-white tracking-[-0.04em] mb-8">
            {t('ai.title')} <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-500 font-light">{t('ai.studio')}</span>
          </h2>
          <p className="mt-4 text-slate-400 max-w-2xl mx-auto text-xl font-medium leading-[1.65] opacity-80">
            {t('ai.description')}
          </p>
        </div>

        {/* Command Center Dashboard */}
        <div className="group/dashboard bg-[#0b1221]/90 rounded-[2.5rem] border border-white/10 shadow-[0_60px_120px_-30px_rgba(0,0,0,0.8)] overflow-hidden ring-1 ring-white/5 backdrop-blur-2xl">
          
          {/* Scientific Toolbar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between px-8 py-5 border-b border-white/5 bg-[#0f172a]/60">
             <div className="flex items-center gap-4 mb-4 md:mb-0">
                <div className="flex gap-2">
                   <div className="w-2.5 h-2.5 rounded-full bg-red-500/40 border border-red-500/60 shadow-[0_0_8px_rgba(239,68,68,0.3)]"></div>
                   <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/40 border border-yellow-500/60 shadow-[0_0_8px_rgba(234,179,8,0.3)]"></div>
                   <div className="w-2.5 h-2.5 rounded-full bg-green-500/40 border border-green-500/60 shadow-[0_0_8px_rgba(34,197,94,0.3)]"></div>
                </div>
                <div className="h-5 w-px bg-white/10 mx-2"></div>
                <div className="flex flex-col">
                   <span className="text-[9px] font-mono text-slate-500 uppercase tracking-[0.2em] leading-none mb-1">System status</span>
                   <span className="text-[10px] font-bold text-accent font-mono tracking-widest leading-none">AI_NODE_ACTIVE_64x</span>
                </div>
             </div>

             <div className="flex items-center gap-6">
                <button 
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-3 rounded-2xl bg-slate-900 border border-white/5 text-slate-400 hover:text-white transition-all shadow-inner hover:border-white/20"
                >
                  {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </button>
                
                <div className="flex bg-slate-900/80 rounded-2xl p-1.5 border border-white/5 shadow-inner">
                  <button
                      onClick={() => { setMode(EditorMode.IMAGE); setGeneratedMedia(null); setError(null); setStatus(ImageEditorStatus.IDLE); }}
                      className={`flex items-center gap-2.5 px-6 py-2.5 rounded-xl text-[10px] font-black tracking-widest uppercase transition-all duration-300 ${
                        mode === EditorMode.IMAGE 
                          ? 'bg-white text-dark shadow-xl' 
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      <ImageIcon className="h-3.5 w-3.5" />
                      {t('ai.tabImage')}
                    </button>
                    <button
                      onClick={() => { setMode(EditorMode.VIDEO); setGeneratedMedia(null); setError(null); setStatus(ImageEditorStatus.IDLE); }}
                      className={`flex items-center gap-2.5 px-6 py-2.5 rounded-xl text-[10px] font-black tracking-widest uppercase transition-all duration-300 ${
                        mode === EditorMode.VIDEO 
                          ? 'bg-white text-dark shadow-xl' 
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      <Video className="h-3.5 w-3.5" />
                      {t('ai.tabVideo')}
                    </button>
                </div>
             </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[720px]">
            
            {/* Operator Control Deck */}
            <div className="lg:col-span-4 border-r border-white/5 bg-[#0b1221]/80 p-8 flex flex-col gap-8">
               
               <div className="space-y-4 flex flex-col">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2">
                      <Terminal className="h-3.5 w-3.5" />
                      {t('ai.step1')}
                    </label>
                    <Hash className="h-3 w-3 text-slate-700" />
                  </div>
                  {mode === EditorMode.IMAGE ? (
                     <div 
                      onClick={() => fileInputRef.current?.click()}
                      className={`relative group h-56 rounded-[2rem] border border-dashed transition-all duration-500 cursor-pointer flex flex-col items-center justify-center overflow-hidden shadow-2xl ${
                        selectedImage 
                          ? 'border-white/20 bg-dark' 
                          : 'border-white/10 bg-slate-900/40 hover:border-accent/50 hover:bg-slate-900'
                      }`}
                    >
                      {selectedImage ? (
                        <img src={selectedImage} alt="Input" className="h-full w-full object-contain p-4 opacity-50 group-hover:opacity-30 transition-opacity" />
                      ) : (
                        <div className="flex flex-col items-center gap-4">
                           <div className="p-5 rounded-3xl bg-white/5 border border-white/5 shadow-xl group-hover:scale-110 group-hover:text-accent transition-all duration-500">
                             <Upload className="h-8 w-8 text-slate-600 group-hover:text-accent" />
                           </div>
                        </div>
                      )}
                      
                      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                         {!selectedImage && <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase mt-4">{t('ai.upload')}</span>}
                         {selectedImage && <span className="text-[10px] text-white font-black opacity-0 group-hover:opacity-100 transition-opacity tracking-[0.3em] uppercase bg-dark/80 px-4 py-2 rounded-full backdrop-blur-sm border border-white/10">{t('ai.clickChange')}</span>}
                      </div>
                      
                      <input ref={fileInputRef} type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                    </div>
                  ) : (
                     <button 
                       onClick={handleKeySelection}
                       className="h-56 w-full rounded-[2rem] border border-dashed border-purple-900/30 bg-purple-900/10 hover:bg-purple-900/20 transition-all flex flex-col items-center justify-center gap-4 text-purple-400 group"
                     >
                        <div className="p-5 rounded-3xl bg-white/5 border border-white/5 transition-transform group-hover:scale-110">
                          <Key className="h-8 w-8" />
                        </div>
                        <span className="text-[10px] font-black tracking-[0.3em] uppercase">{t('ai.selectKey')}</span>
                     </button>
                  )}
               </div>

               <div className="space-y-4 flex flex-col flex-grow">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2">
                      <Zap className="h-3.5 w-3.5" />
                      {mode === EditorMode.IMAGE ? t('ai.step2') : t('ai.stepVideo')}
                    </label>
                    <Settings2 className="h-3.5 w-3.5 text-slate-700" />
                  </div>
                  <div className="relative h-44">
                    <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder={mode === EditorMode.IMAGE ? t('ai.placeholder') : t('ai.placeholderVideo')}
                      className={`w-full h-full bg-dark/80 border border-white/10 rounded-[1.5rem] p-5 text-sm text-slate-200 placeholder-slate-700 focus:outline-none focus:border-accent/40 transition-all resize-none font-mono leading-[1.6] tracking-tight shadow-inner focus:ring-4 focus:ring-accent/5 ${isTyping ? 'animate-pulse' : ''}`}
                    />
                    <div className="absolute bottom-4 right-4 flex gap-2 opacity-30">
                       <Command className="h-3.5 w-3.5 text-slate-500" />
                       <span className="text-[8px] font-mono text-slate-500">PROMPT_ENGINEERING_v2</span>
                    </div>
                  </div>

                  <div className="mt-4 space-y-3">
                    <span className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em] flex items-center gap-2">
                      <Box className="h-3 w-3" />
                      {t('ai.suggestions')}
                    </span>
                    <div className="flex flex-wrap gap-2.5">
                      {SUGGESTED_PROMPTS[language as 'en' | 'pt'][mode].map((s, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSuggestionClick(s)}
                          className="px-3.5 py-2 text-[10px] bg-white/5 border border-white/5 rounded-xl text-slate-400 hover:text-accent hover:border-accent/20 transition-all text-left max-w-full truncate font-bold uppercase tracking-widest shadow-sm hover:shadow-accent/10 hover:bg-accent/5"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
               </div>

               <button
                onClick={handleGenerate}
                disabled={(!prompt || (mode === EditorMode.IMAGE && !selectedImage)) || status === ImageEditorStatus.LOADING}
                className={`w-full py-5 rounded-[1.5rem] font-black text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 active:scale-95 shadow-2xl group ${
                  (!prompt || (mode === EditorMode.IMAGE && !selectedImage)) || status === ImageEditorStatus.LOADING
                    ? 'bg-slate-900 text-slate-700 cursor-not-allowed border border-white/5'
                    : 'bg-white text-dark hover:bg-accent border border-white hover:shadow-[0_20px_40px_-10px_rgba(56,189,248,0.5)] active:translate-y-1'
                }`}
              >
                {status === ImageEditorStatus.LOADING ? (
                  <>
                    <Loader2 className="animate-spin h-5 w-5" />
                    <span>Processing</span>
                  </>
                ) : (
                  <>
                    {mode === EditorMode.IMAGE ? <Sparkles className="h-5 w-5" /> : <Play className="h-5 w-5 fill-dark" />}
                    <span>{mode === EditorMode.IMAGE ? t('ai.generate') : t('ai.generateVideo')}</span>
                  </>
                )}
              </button>
              
              {error && (
                <div className="text-[10px] text-red-400 font-mono border-l-2 border-red-500/50 pl-4 py-3 bg-red-500/5 rounded-r-xl">
                  <div className="font-black text-red-500 uppercase tracking-widest mb-1">Execution_Fault:</div>
                  {error}
                </div>
              )}
            </div>

            {/* Main Visualizer Area */}
            <div className="lg:col-span-8 bg-dark relative flex items-center justify-center overflow-hidden">
               
               <div className="absolute top-6 left-6 z-10 hidden md:block animate-fade-in opacity-40 group-hover/dashboard:opacity-100 transition-opacity duration-700">
                 <div className="flex flex-col gap-2">
                    <div className="text-[9px] font-mono text-slate-600 uppercase tracking-widest flex gap-2">
                       <span className="text-accent">●</span> SENSOR: 1024x1024_SAMPLING
                    </div>
                    <div className="text-[9px] font-mono text-slate-600 uppercase tracking-widest">
                       KERNEL: VEO_TRANSFORMER_09-2025
                    </div>
                 </div>
               </div>

               <div className="absolute bottom-6 right-6 hidden md:block opacity-20 hover:opacity-100 transition-opacity">
                  <div className="flex items-center gap-3 font-mono text-[9px] text-slate-500 uppercase">
                     <span>F_RATE: 24FPS</span>
                     <div className="w-1 h-1 bg-slate-700 rounded-full"></div>
                     <span>BUF: SYNC_READY</span>
                  </div>
               </div>

               {!generatedMedia && status !== ImageEditorStatus.LOADING && (
                 <div className="text-center group/empty transition-all duration-700">
                    <div className="w-[1px] h-32 bg-gradient-to-b from-transparent via-slate-700 to-transparent mx-auto mb-8 transition-all duration-700 group-hover/empty:h-48 group-hover/empty:via-accent"></div>
                    <p className="font-mono text-[10px] text-slate-600 uppercase tracking-[0.5em] group-hover/empty:text-slate-400 transition-colors duration-700">{t('ai.empty')}</p>
                 </div>
               )}

               {status === ImageEditorStatus.LOADING && (
                 <div className="w-full h-full absolute inset-0 bg-dark/95 backdrop-blur-2xl flex flex-col items-center justify-center z-20 p-8">
                    
                    <div className="w-full max-w-sm bg-slate-900/60 backdrop-blur-3xl border border-white/5 rounded-[3rem] p-12 shadow-[0_60px_100px_rgba(0,0,0,0.8)] relative overflow-hidden ring-1 ring-white/10">
                       
                       <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent to-transparent opacity-80 animate-shimmer"></div>

                       <div className="flex flex-col items-center gap-10">
                          
                          <div className="relative">
                            <div className="absolute inset-0 bg-accent/20 rounded-full animate-ping opacity-20"></div>
                            <div className="relative z-10 p-8 rounded-[2.5rem] bg-white/5 border border-white/10 shadow-2xl backdrop-blur-xl transition-all duration-1000">
                               {mode === EditorMode.IMAGE ? (
                                  <Sparkles className="h-14 w-14 text-accent animate-spin-slow" />
                               ) : (
                                  <Video className="h-14 w-14 text-purple-400 animate-pulse" />
                               )}
                            </div>
                          </div>

                          <div className="text-center space-y-4 w-full">
                             <div className="flex items-end justify-center gap-1.5">
                                <span className="text-6xl font-mono font-black text-white tracking-[-0.1em] tabular-nums">
                                   {Math.round(loadingProgress)}
                                </span>
                                <span className="text-lg font-mono text-slate-500 mb-3 opacity-60">%</span>
                             </div>
                             
                             <div className="h-8 flex items-center justify-center">
                                <p className="text-[10px] font-black text-accent uppercase tracking-[0.3em] animate-pulse">
                                   {getLoadingText()}
                                </p>
                             </div>
                          </div>

                          <div className="w-full space-y-2">
                             <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden relative shadow-inner border border-white/5">
                                <div 
                                  className="h-full bg-gradient-to-r from-blue-700 via-accent to-purple-600 rounded-full transition-all duration-500 cubic-bezier(0.16, 1, 0.3, 1) shadow-[0_0_25px_rgba(56,189,248,0.6)]"
                                  style={{ width: `${loadingProgress}%` }}
                                >
                                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent w-full -translate-x-full animate-shimmer"></div>
                                </div>
                             </div>
                             <div className="flex justify-between px-2">
                                <span className="text-[8px] font-mono text-slate-700">SAMPLING_LATENT</span>
                                <span className="text-[8px] font-mono text-slate-700">TENSOR_BUF: 2048</span>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
               )}

               {generatedMedia && (
                 <div className="relative w-full h-full flex items-center justify-center p-12 animate-fade-in">
                    <div className="relative group/media max-w-full max-h-full">
                      <div className="absolute -inset-2 bg-gradient-to-br from-accent/20 to-transparent blur-2xl opacity-40 group-hover/media:opacity-100 transition-opacity"></div>
                      {mode === EditorMode.IMAGE ? (
                        <img src={generatedMedia} alt="Result" className="max-w-full max-h-full relative z-10 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.8)] border border-white/10 rounded-2xl group-hover/media:scale-[1.01] transition-transform duration-700" />
                      ) : (
                        <video src={generatedMedia} controls autoPlay loop className="max-w-full max-h-full relative z-10 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.8)] border border-white/10 rounded-2xl group-hover/media:scale-[1.01] transition-transform duration-700" />
                      )}
                      
                      <div className="absolute inset-0 bg-accent/5 opacity-0 group-hover/media:opacity-100 transition-opacity pointer-events-none rounded-2xl z-20"></div>
                    </div>
                    
                    <div className="absolute top-10 right-10 flex gap-4 z-30">
                       <a 
                          href={generatedMedia}
                          download={mode === EditorMode.IMAGE ? "r8nan-lab-output.png" : "r8nan-lab-output.mp4"}
                          className="group/export relative flex items-center gap-3 px-8 py-3.5 bg-white text-dark text-[11px] font-black uppercase tracking-widest rounded-2xl hover:bg-accent transition-all shadow-[0_20px_40px_-10px_rgba(255,255,255,0.2)] active:scale-95"
                       >
                          <Download className="h-4 w-4" />
                          <span className="relative z-10">{t('ai.download')}</span>
                          <div className="absolute inset-0 bg-accent rounded-2xl opacity-0 group-hover/export:opacity-100 transition-opacity -z-10"></div>
                       </a>
                    </div>
                 </div>
               )}

            </div>

          </div>
        </div>
      </div>
    </section>
  );
};
